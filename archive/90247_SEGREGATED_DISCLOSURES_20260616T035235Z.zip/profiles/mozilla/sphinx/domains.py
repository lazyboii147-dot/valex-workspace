project = "Mozilla Infrastructure Ligation"
author = "Enrique B. Gonzalez III (CL34RBoXx)"
extensions = ["sphinx.ext.autodoc", "sphinx.ext.viewcode"]
xref_strict_enforcement = True
