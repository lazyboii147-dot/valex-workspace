project = 'OMNIBUS v255.0 Forensic Totality'
copyright = '2026, Lead Analyst Enrique B. Gonzalez III'
author = 'Enrique B. Gonzalez III (CL34RBoXx)'
release = '255.0'
extensions = ['sphinx.ext.autodoc', 'sphinx.ext.todo', 'sphinx.ext.viewcode']
html_theme = 'classic'
html_static_path = ['_static']
